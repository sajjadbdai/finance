<?php
require_once __DIR__ . '/db.php';
if (session_status()===PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['auth'])) { echo "Not logged in"; exit; }

$key = GEMINI_API_KEY;
$prompt = "Look up the latest LTP (Last Traded Price) on the Dhaka Stock Exchange (DSE) Bangladesh for these stock symbols: BRACBANK, CITYBANK, MTB";

$payload = [
    'contents' => [['parts'=>[['text'=>$prompt]]]],
    'tools'    => [['google_search'=>new stdClass()]],
    'generationConfig' => [
        'temperature'      => 0,
        'maxOutputTokens'  => 1000,
        'responseMimeType' => 'application/json',
        'responseSchema'   => ['type'=>'OBJECT','additionalProperties'=>['type'=>'NUMBER']]
    ]
];

$ch = curl_init("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key={$key}");
curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
    CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
    CURLOPT_POSTFIELDS=>json_encode($payload),
    CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>false]);
$resp=curl_exec($ch);
$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);
curl_close($ch);

echo "<pre>HTTP: $code\n\n";
$d=json_decode($resp,true);
echo "Raw response:\n".json_encode($d,JSON_PRETTY_PRINT)."\n\n";

$text='';
foreach(($d['candidates'][0]['content']['parts']??[]) as $p) if(isset($p['text'])) $text.=$p['text'];
echo "Extracted text: ".htmlspecialchars($text)."\n\n";
echo "json_decode result: ".print_r(json_decode($text,true),true);
echo "</pre>";
