<?php
ob_start();
require_once __DIR__ . '/db.php';
if (session_status()===PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['auth'])) {
    ob_end_clean();
    http_response_code(403);
    echo json_encode(['results'=>[],'errors'=>['Unauthorized'],'count'=>0]);
    exit;
}

// Always output JSON, catch everything
set_time_limit(120);
ini_set('display_errors', 0);
error_reporting(0);

$results = [];
$errors  = [];

function httpGetR(string $url): ?string {
    $ch = curl_init($url);
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>15,
        CURLOPT_FOLLOWLOCATION=>true,CURLOPT_SSL_VERIFYPEER=>false,
        CURLOPT_USERAGENT=>'Mozilla/5.0',
    ]);
    $res=curl_exec($ch); curl_close($ch);
    return $res?:null;
}

function callGeminiR(string $prompt): ?string {
    $key = defined('GEMINI_API_KEY') ? GEMINI_API_KEY : '';
    if (!$key) return null;
    $models = ['gemini-2.5-flash','gemini-3.5-flash'];
    foreach ($models as $model) {
        try {
            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$key}";
            $payload = [
                'contents'         => [['parts'=>[['text'=>$prompt]]]],
                'generationConfig' => ['temperature'=>0,'maxOutputTokens'=>512],
                'tools'            => [['google_search'=>new stdClass()]],
            ];
            $ch = curl_init($url);
            curl_setopt_array($ch,[
                CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
                CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
                CURLOPT_POSTFIELDS=>json_encode($payload),
                CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>false,
            ]);
            $resp=curl_exec($ch);
            $code=curl_getinfo($ch,CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($code===200&&$resp) {
                $data=json_decode($resp,true);
                $text='';
                foreach(($data['candidates'][0]['content']['parts']??[]) as $p)
                    if(isset($p['text'])) $text.=$p['text'];
                return $text?:null;
            }
            if ($code===429) sleep(4);
        } catch(Exception $e) { continue; }
    }
    return null;
}

function extractPricesR(string $text): array {
    $prices=[];
    $text=preg_replace('/```(?:json)?\s*/i','',$text);
    $text=preg_replace('/```/','',$text);
    $text=trim($text);
    if(substr_count($text,'{')>substr_count($text,'}')) $text.='}';
    $json=json_decode($text,true);
    if(is_array($json)){
        foreach($json as $k=>$v)
            if(is_numeric($v)&&(float)$v>0) $prices[strtoupper(trim($k))]=(float)$v;
        if($prices) return $prices;
    }
    preg_match_all('/"([A-Z0-9]+)"\s*:\s*([\d]+\.?[\d]*)/i',$text,$m);
    foreach($m[1] as $i=>$s) if((float)$m[2][$i]>0) $prices[strtoupper(trim($s))]=(float)$m[2][$i];
    if($prices) return $prices;
    preg_match_all('/\b([A-Z][A-Z0-9]{1,11})\s*=\s*([\d]+\.?[\d]*)/i',$text,$m2);
    foreach($m2[1] as $i=>$s) if((float)$m2[2][$i]>0) $prices[strtoupper(trim($s))]=(float)$m2[2][$i];
    return $prices;
}

try {
    $holdings = db()->query(
        "SELECT symbol,market,exchange,currency,current_price FROM portfolio WHERE quantity>0 ORDER BY market,symbol"
    )->fetchAll();

    $priceMap=[];
    foreach($holdings as $h){
        $sym=strtoupper($h['symbol']);
        $exch=strtoupper($h['exchange']??'');
        $priceMap["{$sym}|{$exch}"]=(float)$h['current_price'];
        $priceMap[$sym]=(float)$h['current_price'];
    }

    $usaStocks=[]; $cryptos=[]; $dseStocks=[]; $cseStocks=[];
    foreach($holdings as $h){
        $sym=strtoupper($h['symbol']);
        $exch=strtoupper($h['exchange']??'');
        $mkt=$h['market']??'';
        if($mkt==='USA'||$mkt==='UK') $usaStocks[]=$sym;
        elseif($mkt==='Crypto') $cryptos[]=$sym;
        elseif($exch==='CSE') $cseStocks[]=$sym;
        else $dseStocks[]=$sym;
    }

    // ── USA ──────────────────────────────────────────────
    foreach(array_unique($usaStocks) as $sym){
        try {
            $resp=httpGetR("https://query1.finance.yahoo.com/v8/finance/chart/{$sym}?interval=1d&range=1d");
            $np=null;
            if($resp){ $d=json_decode($resp,true); $np=$d['chart']['result'][0]['meta']['regularMarketPrice']??null; }
            $op=$priceMap["{$sym}|NYSE"]??$priceMap[$sym]??0;
            if($np){
                $np=round((float)$np,4);
                $results[]=['symbol'=>$sym,'exchange'=>'NYSE','currency'=>'USD',
                    'old_price'=>$op,'new_price'=>$np,
                    'change'=>round($np-$op,4),'change_pct'=>$op>0?round(($np-$op)/$op*100,2):0];
            } else { $errors[]="[NYSE] {$sym}: not found"; }
        } catch(Exception $e){ $errors[]="[NYSE] {$sym}: ".$e->getMessage(); }
        sleep(1);
    }

    // ── Crypto ───────────────────────────────────────────
    if($cryptos){
        try {
            $coinRows=db()->query("SELECT UPPER(symbol) as sym,coin_id FROM portfolio WHERE market='Crypto' AND quantity>0")->fetchAll();
            $coinMap=[];
            foreach($coinRows as $r) if(!empty($r['coin_id'])) $coinMap[$r['sym']]=strtolower(trim($r['coin_id']));
            // defaults
            $defaults=['BTC'=>'bitcoin','BITCOIN'=>'bitcoin','ETH'=>'ethereum','BNB'=>'binancecoin',
                'SOL'=>'solana','XRP'=>'ripple','SHIB'=>'shiba-inu','DOGE'=>'dogecoin',
                'ADA'=>'cardano','PEPE'=>'pepe','MATIC'=>'matic-network'];
            $ids=[]; $symToId=[];
            foreach(array_unique($cryptos) as $sym){
                $id=$coinMap[$sym]??$defaults[$sym]??strtolower($sym);
                $ids[]=$id; $symToId[$id]=$sym;
            }
            $resp=httpGetR("https://api.coingecko.com/api/v3/simple/price?ids=".implode(',',$ids)."&vs_currencies=usd");
            if($resp){
                $data=json_decode($resp,true)??[];
                $found=[];
                foreach($data as $coinId=>$px){
                    $sym=$symToId[$coinId]??strtoupper($coinId);
                    $raw=(float)($px['usd']??0);
                    $op=$priceMap["{$sym}|Crypto"]??$priceMap["{$sym}|CRYPTO"]??$priceMap[$sym]??0;
                    if($raw>0){
                        $results[]=['symbol'=>$sym,'exchange'=>'Crypto','currency'=>'USD',
                            'old_price'=>$op,'new_price'=>$raw,
                            'change'=>round($raw-$op,8),'change_pct'=>$op>0?round(($raw-$op)/$op*100,4):0];
                        $found[]=$sym;
                    }
                }
                foreach(array_unique($cryptos) as $sym)
                    if(!in_array($sym,$found)) $errors[]="[Crypto] {$sym}: not found";
            } else { foreach($cryptos as $s) $errors[]="[Crypto] {$s}: CoinGecko failed"; }
        } catch(Exception $e){ $errors[]="Crypto error: ".$e->getMessage(); }
    }

    // ── DSE stocks (chunks of 3) ──────────────────────────
    foreach(array_chunk(array_unique($dseStocks),3) as $chunk){
        try {
            $syms=implode(', ',$chunk);
            $prompt="Current LTP prices on DSE Bangladesh for: {$syms}\nReturn JSON only: {\"SYMBOL\":price}";
            $text=callGeminiR($prompt);
            $prices=$text?extractPricesR($text):[];
            foreach($chunk as $sym){
                $op=$priceMap["{$sym}|DSE"]??$priceMap[$sym]??0;
                $np=$prices[$sym]??null;
                if($np&&$np>0){
                // Sanity check: reject if >80% different from old price (likely parse error)
                $pctDiff = $op>0 ? abs($np-$op)/$op*100 : 0;
                if($op>0 && $pctDiff>80){
                    $errors[]="[DSE] {$sym}: suspicious price {$np} (was {$op}, {$pctDiff}% diff) - skipped";
                } else {
                    $results[]=['symbol'=>$sym,'exchange'=>'DSE','currency'=>'BDT',
                        'old_price'=>$op,'new_price'=>round($np,2),
                        'change'=>round($np-$op,2),'change_pct'=>$op>0?round(($np-$op)/$op*100,2):0];
                }
            } else $errors[]="[DSE] {$sym}: not found";
            }
        } catch(Exception $e){ foreach($chunk as $s) $errors[]="[DSE] {$s}: ".$e->getMessage(); }
        sleep(3);
    }

    // ── Retry missing DSE stocks individually ────────────────
    $foundDSE = array_column(array_filter($results, function($r){return $r['exchange']==='DSE';}), 'symbol');
    $missingDSE = array_diff(array_unique($dseStocks), $foundDSE);
    foreach($missingDSE as $sym){
        try {
            $op=$priceMap["{$sym}|DSE"]??$priceMap[$sym]??0;
            $prompt="What is the latest LTP of {$sym} stock on DSE Dhaka Stock Exchange Bangladesh? Reply with ONLY the price number.";
            $text=callGeminiR($prompt);
            if($text){
                preg_match('/([\d]+\.?[\d]*)/', trim(strip_tags($text)), $m);
                $np=isset($m[1])?(float)$m[1]:0;
                $pctDiff=$op>0?abs($np-$op)/$op*100:0;
                if($np>0&&$np<100000&&($op==0||$pctDiff<80))
                    $results[]=['symbol'=>$sym,'exchange'=>'DSE','currency'=>'BDT',
                        'old_price'=>$op,'new_price'=>round($np,2),
                        'change'=>round($np-$op,2),'change_pct'=>$op>0?round(($np-$op)/$op*100,2):0];
                else $errors[]="[DSE] {$sym}: price {$np} rejected";
            } else $errors[]="[DSE] {$sym}: Gemini failed";
        } catch(Exception $e){ $errors[]="[DSE] {$sym}: ".$e->getMessage(); }
        sleep(2);
    }

    // ── CSE stocks (chunks of 2) ──────────────────────────
    foreach(array_chunk(array_unique($cseStocks),2) as $chunk){
        try {
            $syms=implode(', ',$chunk);
            $prompt="Current LTP prices on CSE Chittagong Bangladesh for: {$syms}\nReturn JSON only: {\"SYMBOL\":price}";
            $text=callGeminiR($prompt);
            $prices=$text?extractPricesR($text):[];
            foreach($chunk as $sym){
                $op=$priceMap["{$sym}|CSE"]??$priceMap[$sym]??0;
                $np=$prices[$sym]??null;
                if($np&&$np>0){
                $pctDiff = $op>0 ? abs($np-$op)/$op*100 : 0;
                if($op>0 && $pctDiff>80){
                    $errors[]="[CSE] {$sym}: suspicious price {$np} (was {$op}) - skipped";
                } else {
                    $results[]=['symbol'=>$sym,'exchange'=>'CSE','currency'=>'BDT',
                        'old_price'=>$op,'new_price'=>round($np,2),
                        'change'=>round($np-$op,2),'change_pct'=>$op>0?round(($np-$op)/$op*100,2):0];
                }
            } else $errors[]="[CSE] {$sym}: not found";
            }
        } catch(Exception $e){ foreach($chunk as $s) $errors[]="[CSE] {$s}: ".$e->getMessage(); }
        sleep(3);
    }

    // ── Retry missing CSE stocks individually ────────────────
    $foundCSE = array_column(array_filter($results, function($r){return $r['exchange']==='CSE';}), 'symbol');
    $missingCSE = array_diff(array_unique($cseStocks), $foundCSE);
    foreach($missingCSE as $sym){
        try {
            $op=$priceMap["{$sym}|CSE"]??$priceMap[$sym]??0;
            $prompt="What is the latest LTP of {$sym} stock on CSE Chittagong Stock Exchange Bangladesh? Reply with ONLY the price number.";
            $text=callGeminiR($prompt);
            if($text){
                preg_match('/([\d]+\.?[\d]*)/', trim(strip_tags($text)), $m);
                $np=isset($m[1])?(float)$m[1]:0;
                $pctDiff=$op>0?abs($np-$op)/$op*100:0;
                if($np>0&&$np<100000&&($op==0||$pctDiff<80))
                    $results[]=['symbol'=>$sym,'exchange'=>'CSE','currency'=>'BDT',
                        'old_price'=>$op,'new_price'=>round($np,2),
                        'change'=>round($np-$op,2),'change_pct'=>$op>0?round(($np-$op)/$op*100,2):0];
                else $errors[]="[CSE] {$sym}: price {$np} rejected";
            } else $errors[]="[CSE] {$sym}: Gemini failed";
        } catch(Exception $e){ $errors[]="[CSE] {$sym}: ".$e->getMessage(); }
        sleep(2);
    }

} catch(Exception $e){
    $errors[]="Fatal: ".$e->getMessage();
}

// Always output valid JSON
ob_end_clean();
header('Content-Type: application/json');
echo json_encode(['results'=>$results,'errors'=>$errors,'count'=>count($results)]);
