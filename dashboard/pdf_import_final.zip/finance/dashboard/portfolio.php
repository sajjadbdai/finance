<?php
require_once __DIR__ . '/db.php';
if (session_status()===PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['auth'])) { header('Location: /dashboard/login.php'); exit; }
$pageTitle='Investment Portfolio'; $activePage='portfolio';

// Create table if not exists
try {
    db()->exec("CREATE TABLE IF NOT EXISTS portfolio (
        id INT AUTO_INCREMENT PRIMARY KEY,
        account_id INT,
        symbol VARCHAR(20) NOT NULL,
        company_name VARCHAR(100) NOT NULL,
        market ENUM('BD','USA','UK','Crypto','Other') DEFAULT 'BD',
        quantity DECIMAL(15,4) NOT NULL DEFAULT 0,
        avg_cost DECIMAL(15,4) NOT NULL DEFAULT 0,
        currency VARCHAR(10) DEFAULT 'BDT',
        current_price DECIMAL(15,4) DEFAULT 0,
        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch(Exception $e){}

$msg=''; $error=''; $editItem=null;

// Delete
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    db()->prepare("DELETE FROM portfolio WHERE id=?")->execute([(int)$_GET['delete']]);
    header('Location: /dashboard/portfolio.php?msg=deleted'); exit;
}
// Edit load
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $st=db()->prepare("SELECT * FROM portfolio WHERE id=?"); $st->execute([(int)$_GET['edit']]);
    $editItem=$st->fetch();
}
$msg = $_GET['msg'] ?? '';

// Save
if (isset($_POST['do_save'])) {
    $sid      = (int)($_POST['sid'] ?? 0);
    $symbol   = strtoupper(trim($_POST['symbol']       ?? ''));
    $name     = trim($_POST['company_name']             ?? '');
    $market   = $_POST['market']                        ?? 'BD';
    $qty      = (float)($_POST['quantity']              ?? 0);
    $avgCost  = (float)($_POST['avg_cost']              ?? 0);
    $currency = $_POST['currency']                      ?? 'BDT';
    $curPrice = (float)($_POST['current_price']         ?? 0);
    $accId    = (int)($_POST['account_id']              ?? 0) ?: null;
    $notes    = trim($_POST['notes']                    ?? '');

    if (!$symbol || !$name) { $error='Symbol and name required.'; }
    else {
        if ($sid) {
            $exch = strtoupper($_POST['exchange'] ?? 'DSE');
            db()->prepare("UPDATE portfolio SET symbol=?,company_name=?,market=?,exchange=?,quantity=?,avg_cost=?,currency=?,current_price=?,account_id=?,notes=?,last_updated=NOW() WHERE id=?")
            ->execute([$symbol,$name,$market,$exch,$qty,$avgCost,$currency,$curPrice,$accId,$notes,$sid]);
        } else {
            $exch = strtoupper($_POST['exchange'] ?? 'DSE');
            db()->prepare("INSERT INTO portfolio (symbol,company_name,market,exchange,quantity,avg_cost,currency,current_price,account_id,notes) VALUES (?,?,?,?,?,?,?,?,?,?)")
            ->execute([$symbol,$name,$market,$exch,$qty,$avgCost,$currency,$curPrice,$accId,$notes]);
        }
        header('Location: /dashboard/portfolio.php?msg=saved'); exit;
    }
}

// Update price only
if (isset($_POST['update_price'])) {
    $pid   = (int)($_POST['pid']   ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    db()->prepare("UPDATE portfolio SET current_price=?,last_updated=NOW() WHERE id=?")->execute([$price,$pid]);
    header('Location: /dashboard/portfolio.php?msg=updated'); exit;
}

$holdings = db()->query("SELECT p.*,a.name as acc_name FROM portfolio p LEFT JOIN accounts a ON a.id=p.account_id ORDER BY p.market,p.symbol")->fetchAll();
$accounts = db()->query("SELECT id,name,currency FROM accounts WHERE is_active=1 AND group_name IN ('Investments','Other Currencies Account') ORDER BY name")->fetchAll();

// Calculate totals by market
$markets=['BD'=>[],'USA'=>[],'UK'=>[],'Crypto'=>[],'Other'=>[]];
$totalCostBHD=0; $totalValueBHD=0;
foreach($holdings as $h) {
    $cost    = (float)$h['quantity'] * (float)$h['avg_cost'];
    $value   = (float)$h['quantity'] * (float)$h['current_price'];
    $pl      = $value - $cost;
    $plPct   = $cost > 0 ? round($pl/$cost*100,2) : 0;
    $costBHD = toBHD($cost, $h['currency']);
    $valBHD  = toBHD($value, $h['currency']);
    $totalCostBHD  += $costBHD;
    $totalValueBHD += $valBHD;
    $markets[$h['market']][] = array_merge($h,compact('cost','value','pl','plPct','costBHD','valBHD'));
}

require 'header.php';
?>
<?php if($msg==='saved'):?><div class="alert alert-success">✅ Saved!</div><?php endif;?>
<?php if($msg==='deleted'):?><div class="alert alert-danger">🗑 Deleted.</div><?php endif;?>
<?php if($msg==='updated'):?><div class="alert alert-success">✅ Price updated!</div><?php endif;?>
<?php if($error):?><div class="alert alert-danger">❌ <?=htmlspecialchars($error)?></div><?php endif;?>

<!-- Price Update Modal -->
<div id="price-modal" style="display:none;position:fixed;inset:0;background:#00000090;z-index:1000;overflow-y:auto;padding:20px;">
  <div style="background:var(--s1);border-radius:14px;max-width:600px;margin:20px auto;padding:20px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <div style="font-weight:700;font-size:1rem;">📈 Price Update Preview</div>
      <button onclick="closeModal()" style="background:none;border:none;color:var(--muted);font-size:1.3rem;cursor:pointer;">✕</button>
    </div>
    <div id="modal-loading" style="text-align:center;padding:30px;">
      <div style="font-size:2rem;margin-bottom:10px;">⏳</div>
      <div style="color:var(--muted);">Fetching latest prices...<br><small>This may take 30-60 seconds</small></div>
    </div>
    <div id="modal-results" style="display:none;">
      <div id="price-table"></div>
      <div id="modal-errors" style="margin-top:10px;font-size:.8rem;color:var(--red);"></div>
      <div style="display:flex;gap:10px;margin-top:16px;flex-wrap:wrap;">
        <button onclick="saveAllPrices()" class="btn btn-success" id="save-all-btn">✅ Save Checked Prices</button>
        <button onclick="closeModal()" class="btn btn-ghost">❌ Cancel</button>
      </div>
    </div>
  </div>
</div>

<!-- Export buttons -->
<div class="gap-2" style="margin-bottom:16px;">
  <button onclick="openPriceUpdate()" class="btn btn-primary btn-sm">🔄 Update Prices</button>
  <a href="import_portfolio_pdf.php" class="btn btn-success btn-sm">📧 Import from PDF</a>
  <a href="portfolio_export.php?format=pdf" target="_blank" class="btn btn-ghost btn-sm">🖨️ Report</a>
  <a href="portfolio_export.php?format=csv" class="btn btn-ghost btn-sm">⬇️ CSV</a>
</div>

<!-- Email Sync Modal -->
<div id="email-modal" style="display:none;position:fixed;inset:0;background:#00000090;z-index:1000;overflow-y:auto;padding:20px;">
  <div style="background:var(--s1);border-radius:14px;max-width:500px;margin:20px auto;padding:24px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <div style="font-weight:700;">📧 Sync from BRAC EPL Email</div>
      <button onclick="closeEmailModal()" style="background:none;border:none;color:var(--muted);font-size:1.3rem;cursor:pointer;">✕</button>
    </div>
    <div id="email-loading" style="text-align:center;padding:20px;">
      <div style="font-size:2rem;">⏳</div>
      <div style="color:var(--muted);margin-top:8px;">Reading latest portfolio emails...<br><small>BRAC EPL + Berich PDFs · auto-saving when done</small></div>
    </div>
    <div id="email-results" style="display:none;">
      <div id="email-table"></div>
      <div style="display:flex;gap:8px;margin-top:16px;align-items:center;">
        <button class="btn btn-success" id="email-save-btn" disabled>⏳ Auto-saving...</button>
        <button onclick="closeEmailModal()" class="btn btn-ghost">✕ Close</button>
      </div>
    </div>
    <div id="email-error" style="display:none;color:var(--red);padding:12px;"></div>
  </div>
</div>

<!-- Portfolio Summary -->
<div class="g3" style="margin-bottom:20px;">
  <div class="card"><div class="card-title">Total Cost</div><div class="card-value c-blue">BD <?=number_format($totalCostBHD,2)?></div></div>
  <div class="card"><div class="card-title">Current Value</div><div class="card-value c-blue">BD <?=number_format($totalValueBHD,2)?></div></div>
  <div class="card">
    <?php $totalPL=$totalValueBHD-$totalCostBHD; $totalPLPct=$totalCostBHD>0?round($totalPL/$totalCostBHD*100,2):0;?>
    <div class="card-title">Unrealized P&L</div>
    <div class="card-value <?=$totalPL>=0?'c-green':'c-red'?>">BD <?=number_format($totalPL,2)?></div>
    <div class="card-sub <?=$totalPL>=0?'c-green':'c-red'?>"><?=$totalPLPct>=0?'+':''?><?=$totalPLPct?>%</div>
  </div>
</div>

<div class="g2">
<!-- Add/Edit Form -->
<div>
  <!-- Price Update Modal -->


<div class="section-header">
    <div class="section-title"><?=$editItem?'Edit':'Add'?> Holding</div>
    <?php if($editItem):?><a href="portfolio.php" class="btn btn-ghost btn-sm">+ New</a><?php endif;?>
  </div>
  <div class="card">
    <form method="POST" action="portfolio.php">
      <input type="hidden" name="do_save" value="1">
      <input type="hidden" name="sid" value="<?=$editItem?$editItem['id']:0?>">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Symbol *</label>
          <input class="form-control" name="symbol" value="<?=htmlspecialchars($editItem['symbol']??'')?>" placeholder="e.g. NVDA, BTC" style="text-transform:uppercase;" required autofocus>
        </div>
        <div class="form-group">
          <label class="form-label">Market</label>
          <input list="market_list" class="form-control" name="market" id="mkt_select"
                 value="<?=htmlspecialchars($editItem['market']??'BD')?>"
                 onchange="updateExchangeHint(this.value)" placeholder="e.g. BD, USA, Crypto">
          <datalist id="market_list">
            <option value="BD">🇧🇩 Bangladesh</option>
            <option value="USA">🇺🇸 USA</option>
            <option value="UK">🇬🇧 UK</option>
            <option value="Crypto">🪙 Crypto</option>
            <option value="Japan">🇯🇵 Japan</option>
            <option value="India">🇮🇳 India</option>
            <option value="UAE">🇦🇪 UAE</option>
            <option value="Other">🌐 Other</option>
          </datalist>
        </div>
        <div class="form-group">
          <label class="form-label">Exchange</label>
          <input list="exchange_list" class="form-control" name="exchange" id="exch_select"
                 value="<?=htmlspecialchars($editItem['exchange']??'DSE')?>"
                 placeholder="e.g. DSE, NYSE, Crypto">
          <datalist id="exchange_list">
            <option value="DSE">DSE - Dhaka Stock Exchange</option>
            <option value="CSE">CSE - Chittagong Stock Exchange</option>
            <option value="NYSE">NYSE - New York</option>
            <option value="NASDAQ">NASDAQ</option>
            <option value="LSE">LSE - London</option>
            <option value="BSE">BSE - Bombay</option>
            <option value="NSE">NSE - National India</option>
            <option value="TSE">TSE - Tokyo</option>
            <option value="Crypto">Crypto (CoinGecko)</option>
            <option value="Other">Other</option>
          </datalist>
          <div class="hint" id="exchange_hint"></div>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Company/Asset Name *</label>
        <input class="form-control" name="company_name" value="<?=htmlspecialchars($editItem['company_name']??'')?>" placeholder="e.g. Nvidia, Bitcoin" required>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Quantity</label>
          <input class="form-control" type="number" step="0.0001" name="quantity" value="<?=htmlspecialchars($editItem['quantity']??0)?>">
        </div>
        <div class="form-group">
          <label class="form-label">Currency</label>
          <select class="form-control" name="currency">
            <?php foreach(['BDT'=>'BDT','USD'=>'USD','GBP'=>'GBP','BHD'=>'BHD'] as $v=>$l):?>
            <option value="<?=$v?>" <?=($editItem['currency']??'BDT')===$v?'selected':''?>><?=$l?></option>
            <?php endforeach;?>
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Avg. Buy Price</label>
          <input class="form-control" type="number" step="any" name="avg_cost" value="<?=htmlspecialchars($editItem['avg_cost']??0)?>">
        </div>
        <div class="form-group">
          <label class="form-label">Current Price</label>
          <input class="form-control" type="number" step="any" name="current_price" value="<?=htmlspecialchars($editItem['current_price']??0)?>">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Linked Account (optional)</label>
        <select class="form-control" name="account_id">
          <option value="">— None —</option>
          <?php foreach($accounts as $a):?><option value="<?=$a['id']?>" <?=($editItem['account_id']??0)==$a['id']?'selected':''?>><?=htmlspecialchars($a['name'])?></option><?php endforeach;?>
        </select>
      </div>
      <div class="form-group">
        <label class="form-label">Notes</label>
        <input class="form-control" name="notes" value="<?=htmlspecialchars($editItem['notes']??'')?>" placeholder="e.g. Berich account 179387">
      </div>
      <div class="gap-2">
        <button type="submit" class="btn btn-primary"><?=$editItem?'💾 Save':'✅ Add Holding'?></button>
        <?php if($editItem):?><a href="portfolio.php" class="btn btn-ghost">Cancel</a><?php endif;?>
      </div>
    </form>
  </div>
</div>

<!-- Holdings by Market -->
<div>
  <?php foreach($markets as $mkt=>$items): if(!$items) continue;
    $mktCost=array_sum(array_column($items,'costBHD'));
    $mktVal=array_sum(array_column($items,'valBHD'));
    $mktPL=$mktVal-$mktCost;
    $mktLabel=['BD'=>'🇧🇩 Bangladesh','USA'=>'🇺🇸 USA','UK'=>'🇬🇧 UK','Crypto'=>'🪙 Crypto','Other'=>'🌐 Other'][$mkt]??$mkt;
  ?>
  <div class="card" style="margin-bottom:12px;padding:0;overflow:hidden;">
    <div style="background:var(--s2);padding:10px 16px;display:flex;justify-content:space-between;align-items:center;">
      <span style="font-weight:700;"><?=$mktLabel?></span>
      <div style="text-align:right;">
        <span style="font-size:.82rem;color:var(--muted);">BD <?=number_format($mktVal,2)?></span>
        <span class="<?=$mktPL>=0?'c-green':'c-red'?>" style="margin-left:10px;font-size:.82rem;font-weight:700;"><?=$mktPL>=0?'+':''?><?=number_format($mktPL,2)?></span>
      </div>
    </div>
    <table class="tbl" style="font-size:.82rem;">
      <thead><tr><th>Symbol</th><th>Qty</th><th>Avg Cost</th><th>Curr Price</th><th>Value</th><th>P&L</th><th></th></tr></thead>
      <tbody>
        <?php foreach($items as $h):
          $plColor = $h['pl'] >= 0 ? 'c-green' : 'c-red';
        ?>
        <tr>
          <td>
            <div style="font-weight:700;"><?=htmlspecialchars($h['symbol'])?></div>
            <div style="font-size:.72rem;color:var(--muted);"><?=htmlspecialchars($h['company_name'])?></div>
          </td>
          <td><?=number_format((float)$h['quantity'],2)?></td>
          <td><?=number_format((float)$h['avg_cost'],2)?> <?=$h['currency']?></td>
          <td>
            <!-- Inline price update -->
            <form method="POST" action="portfolio.php" style="display:flex;gap:4px;align-items:center;">
              <input type="hidden" name="update_price" value="1">
              <input type="hidden" name="pid" value="<?=$h['id']?>">
              <input type="number" step="0.0001" name="price" value="<?=htmlspecialchars($h['current_price'])?>" style="width:70px;padding:4px 6px;background:var(--s2);border:1px solid var(--s3);border-radius:5px;color:var(--text);font-size:.78rem;">
              <button type="submit" style="background:var(--blue);color:#fff;border:none;padding:4px 6px;border-radius:5px;cursor:pointer;font-size:.75rem;">✓</button>
            </form>
            <div style="font-size:.68rem;color:var(--muted);">Updated: <?=date('d M',strtotime($h['last_updated']))?></div>
          </td>
          <td>
            <div style="font-weight:600;"><?=number_format($h['value'],2)?> <?=$h['currency']?></div>
            <div style="font-size:.72rem;color:var(--muted);">BD <?=number_format($h['valBHD'],2)?></div>
          </td>
          <td class="<?=$plColor?>" style="font-weight:600;">
            <?=$h['pl']>=0?'+':''?><?=number_format($h['pl'],2)?><br>
            <span style="font-size:.72rem;"><?=$h['plPct']>=0?'+':''?><?=$h['plPct']?>%</span>
          </td>
          <td>
            <div class="gap-2">
              <a href="portfolio.php?edit=<?=$h['id']?>" class="btn btn-ghost btn-sm">✏️</a>
              <a href="portfolio.php?delete=<?=$h['id']?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete?')">🗑</a>
            </div>
          </td>
        </tr>
        <?php endforeach;?>
      </tbody>
    </table>
  </div>
  <?php endforeach;?>
</div>
</div>
<script>
let fetchedPrices = [];

function openPriceUpdate() {
    document.getElementById('price-modal').style.display = 'block';
    document.getElementById('modal-loading').style.display = 'block';
    document.getElementById('modal-results').style.display = 'none';
    document.body.style.overflow = 'hidden';

    // 3 minute timeout for fetch
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 180000);

    fetch('/dashboard/run_price_update.php', {signal: controller.signal})
        .then(r => { clearTimeout(timeout); return r.json(); })
        .then(data => {
            fetchedPrices = data.results || [];
            renderPriceTable(fetchedPrices, data.errors || []);
        })
        .catch(err => {
            document.getElementById('modal-loading').innerHTML = '❌ Error: ' + err.message;
        });
}

function renderPriceTable(results, errors) {
    document.getElementById('modal-loading').style.display = 'none';
    document.getElementById('modal-results').style.display = 'block';

    let html = '<table style="width:100%;border-collapse:collapse;font-size:.85rem;">';
    html += '<tr style="color:var(--muted);font-size:.75rem;"><th style="padding:8px;text-align:left;">Symbol</th><th style="padding:8px;text-align:right;">Old Price</th><th style="padding:8px;text-align:right;">New Price</th><th style="padding:8px;text-align:right;">Change</th><th style="padding:8px;text-align:center;">Action</th></tr>';

    results.forEach((r, i) => {
        const changeColor = r.change > 0 ? '#2ecc71' : r.change < 0 ? '#e74c3c' : '#8892a4';
        const changeSign  = r.change > 0 ? '+' : '';
        const arrow       = r.change > 0 ? '📈' : r.change < 0 ? '📉' : '➡️';
        html += `<tr style="border-top:1px solid var(--s3);">
            <td style="padding:8px;font-weight:600;">${r.symbol}<br><small style="color:var(--muted);font-weight:normal;">${r.exchange} · ${r.currency}</small></td>
            <td style="padding:8px;text-align:right;color:var(--muted);">${r.old_price.toFixed(2)}</td>
            <td style="padding:8px;text-align:right;font-weight:700;">${r.new_price.toFixed(2)}</td>
            <td style="padding:8px;text-align:right;color:${changeColor};">${arrow} ${changeSign}${r.change.toFixed(2)}<br><small>${changeSign}${r.change_pct}%</small></td>
            <td style="padding:8px;text-align:center;">
                <label style="cursor:pointer;display:flex;align-items:center;gap:6px;justify-content:center;">
                    <input type="checkbox" id="chk_${i}" checked style="width:16px;height:16px;accent-color:var(--blue);">
                    <span style="font-size:.75rem;color:var(--muted);">Include</span>
                </label>
            </td>
        </tr>`;
    });
    html += '</table>';

    document.getElementById('price-table').innerHTML = html;

    if (errors.length > 0) {
        document.getElementById('modal-errors').innerHTML = '⚠️ Not found: ' + errors.join(', ');
    }
}

function saveAllPrices() {
    const btn = document.getElementById('save-all-btn');
    btn.disabled = true;
    btn.textContent = '⏳ Saving...';

    // Only save checked prices
    const toSave = fetchedPrices.filter((r, i) => {
        const chk = document.getElementById('chk_' + i);
        return chk && chk.checked;
    });

    fetch('/dashboard/save_prices.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({prices: toSave})
    })
    .then(r => r.json())
    .then(data => {
        btn.textContent = '✅ Saved ' + data.saved + ' prices!';
        setTimeout(() => { closeModal(); location.reload(); }, 1500);
    })
    .catch(() => { btn.textContent = '❌ Save failed'; btn.disabled = false; });
}

function syncFromEmail() {
    document.getElementById('email-modal').style.display = 'block';
    document.getElementById('email-loading').style.display = 'block';
    document.getElementById('email-results').style.display = 'none';
    document.getElementById('email-error').style.display = 'none';
    document.body.style.overflow = 'hidden';

    // Call our PHP endpoint that uses Claude to read Gmail
    fetch('/dashboard/read_email_prices.php')
        .then(r => r.json())
        .then(data => {
            document.getElementById('email-loading').style.display = 'none';
            if(data.error){
                document.getElementById('email-error').textContent = '❌ ' + data.error;
                document.getElementById('email-error').style.display = 'block';
                return;
            }
            emailPrices = data.prices || [];

            // Build preview table
            let html = '<div style="font-size:.82rem;color:var(--muted);margin-bottom:8px;">📅 ' + (data.date||'') + ' · ' + (data.source||'Broker Email') + '</div>';
            html += `<div style="font-size:.8rem;margin-bottom:12px;">
                <span style="color:var(--blue);">● ${data.brac_epl||0} DSE stocks (BRAC EPL)</span>
                &nbsp;&nbsp;
                <span style="color:var(--green);">● ${data.berich||0} CSE stocks (Berich)</span>
            </div>`;
            html += '<table style="width:100%;border-collapse:collapse;font-size:.85rem;">';
            html += '<tr style="color:var(--muted);font-size:.72rem;border-bottom:1px solid var(--s3);"><th style="padding:6px;text-align:left;">Symbol</th><th style="padding:6px;text-align:left;">Broker</th><th style="padding:6px;text-align:right;">Price (BDT)</th></tr>';
            emailPrices.forEach((p,i) => {
                const bc = p.exchange==='DSE' ? 'var(--blue)' : 'var(--green)';
                html += `<tr style="border-bottom:1px solid var(--s3);">
                    <td style="padding:6px;font-weight:600;">${p.symbol} <small style="color:var(--muted);font-weight:normal;">${p.exchange}</small></td>
                    <td style="padding:6px;font-size:.75rem;color:${bc};">${p.broker||p.exchange}</td>
                    <td style="padding:6px;text-align:right;font-weight:600;">${p.price.toFixed(2)}</td>
                </tr>`;
            });
            html += '</table>';
            document.getElementById('email-table').innerHTML = html;
            document.getElementById('email-results').style.display = 'block';

            // AUTO-SAVE immediately - no manual confirmation needed
            document.getElementById('email-save-btn').textContent = '⏳ Saving...';
            document.getElementById('email-save-btn').disabled = true;
            fetch('/dashboard/sync_email_prices.php', {
                method:'POST', headers:{'Content-Type':'application/json'},
                body: JSON.stringify({prices: emailPrices})
            }).then(r=>r.json()).then(d => {
                document.getElementById('email-save-btn').textContent = '✅ Saved ' + d.saved + ' prices!';
                document.getElementById('email-save-btn').style.background = 'var(--green)';
                setTimeout(() => { closeEmailModal(); location.reload(); }, 2000);
            }).catch(() => {
                document.getElementById('email-save-btn').textContent = '❌ Save failed — try manually';
                document.getElementById('email-save-btn').disabled = false;
            });
        })
        .catch(err => {
            document.getElementById('email-loading').style.display = 'none';
            if(err === 'cancelled') {
                closeEmailModal();
                // Redirect to PDF upload
                window.location.href = '/dashboard/import_portfolio_pdf.php';
            } else {
                document.getElementById('email-error').innerHTML =
                    '❌ ' + (err.message||err) +
                    '<br><br><a href="/dashboard/import_portfolio_pdf.php" class="btn btn-primary btn-sm" style="margin-top:8px;">📄 Use PDF Upload instead</a>';
                document.getElementById('email-error').style.display = 'block';
            }
        });
}

let emailPrices = [];

async function getGmailToken() {
    return new Promise((resolve, reject) => {
        // Try Google Identity Services (GSI) - available if user is signed into Google
        if (window.google && window.google.accounts && window.google.accounts.oauth2) {
            const client = window.google.accounts.oauth2.initTokenClient({
                client_id: '', // Not needed for token refresh
                scope: 'https://www.googleapis.com/auth/gmail.readonly',
                callback: (response) => {
                    if (response.access_token) resolve(response.access_token);
                    else reject('Could not get Gmail token');
                }
            });
            client.requestAccessToken({prompt: ''});
        } else {
            // Fallback: ask user to paste token
            const token = prompt(
                'Gmail sync needs your Gmail OAuth token.\n\n' +
                'Get it from: https://accounts.google.com/o/oauth2/v2/auth\n\n' +
                'Or use the Upload PDF option instead (📄 Upload PDF button)\n\n' +
                'Paste token here (or cancel to use PDF upload):'
            );
            if (token && token.trim()) resolve(token.trim());
            else reject('cancelled');
        }
    });
}
function saveEmailPrices() {
    const btn = document.getElementById('email-save-btn');
    btn.disabled = true; btn.textContent = '⏳ Saving...';
    const toSave = emailPrices.filter((_,i) => {
        const c = document.getElementById('echk_'+i); return c && c.checked;
    });
    fetch('/dashboard/sync_email_prices.php', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({prices: toSave})
    }).then(r=>r.json()).then(d => {
        btn.textContent = '✅ Saved ' + d.saved + ' prices!';
        setTimeout(() => { closeEmailModal(); location.reload(); }, 1500);
    }).catch(() => { btn.textContent='❌ Failed'; btn.disabled=false; });
}

function closeEmailModal() {
    document.getElementById('email-modal').style.display = 'none';
    document.body.style.overflow = '';
}

function closeModal() {
    document.getElementById('price-modal').style.display = 'none';
    document.body.style.overflow = '';
}
</script>



<?php require 'footer.php'; ?>
