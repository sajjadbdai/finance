<?php
// ============================================================
//  SAJJAD FINANCE — config.php
//  Fill in your secrets here. Never share this file.
// ============================================================

// --- Anthropic Claude API ---
define('ANTHROPIC_API_KEY', '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');
define('ANTHROPIC_MODEL',   'claude-haiku-4-5-20251001');
define('GEMINI_API_KEY', 'AIzaSyD7i3irDM7_tYVI8PO8rDtCj8iZGzHt55Y');

// --- Telegram Bot ---
define('TELEGRAM_BOT_TOKEN', '8848712549:AAHUlHZLbFZHnMpZM075r4hZDOSGz_v7C64');
define('TELEGRAM_API',       'https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN);
define('YOUR_TELEGRAM_ID',   1615708650);   // your numeric Telegram user ID (get from @userinfobot)

// --- MySQL Database (from Exonhost cPanel) ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'sajjadbd_fin');
define('DB_USER', 'sajjadbd_fin');
define('DB_PASS', 'Dajjas@1976');

// --- Site ---
define('SITE_URL',    'https://finance.sajjad.bd');
define('WEBHOOK_URL', SITE_URL . '/bot/webhook.php');

// --- Default currencies shown ---
define('PRIMARY_CURRENCY',   'BHD');
define('SECONDARY_CURRENCY', 'BDT');

// --- Timezone ---
date_default_timezone_set('Asia/Bahrain');

// --- Security: simple dashboard password (change this!) ---
define('DASHBOARD_PASSWORD', 'Dajjas@1976');
